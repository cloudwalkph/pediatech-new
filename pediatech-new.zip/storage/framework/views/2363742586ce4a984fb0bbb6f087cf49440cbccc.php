<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('img/banner.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-heading">
                        <h1>SYNEX<sup>TM</sup></h1>
                        <span class="subheading">Safe and Effective Natural Products.</span> <br>
                        <span class="subheading">Synex products aim to fulfill our promise of delivering natural <br>
                            products good enough for our own family.</span> <br>
                        <button class="btn btn-transparent">Learn More</button>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div id="main">
        <div class="separator-gradient"></div>
        <div class="container">
            <div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 carousel-text">
                <p>
                    <b>Synex</b> is a research-based pharmaceutical organization dedicated to the advancement of natural
                    healthcare products by designing products that are natural, safe, and effective
                </p>
                <hr>
                <p>How do we deliver this promise?</p>
            </div>

            <div class="col-md-12">
                <div class="wrap">
                    <div id="showcase" class="noselect">
                        <div class="card">
                            <img src="/img/carousel1.jpg" class="img-responsive">
                            <h4>World Class Partner Institutions</h4>
                            <p>
                            Our active ingredients are sourced from leading research institutions around the world.
                            </p>
                        </div>
                        <div class="card">
                            <img src="/img/carousel2.jpg" class="img-responsive">
                            <h4>Stronger, Safety and Efficacy</h4>
                            <p>
                            We only use ingredients with credible scientific evidence backing its safety and efficacy.
                            </p>
                        </div>
                        <div class="card">
                            <img src="/img/carousel3.jpg" class="img-responsive">
                            <h4>Mother Nature Inspires Us</h4>
                            <p>
                            The world's leading drugs in various fields such as cancer therapy, hypertension and neurology were all derived from nature. We believe that nature has more to offer us.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <!-- Footer -->
        <footer>
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->

                <div class="row">
                    <div class="col-md-4 img-footer">
                        <img src="img/synex-footer.png" alt="logo" height="125">
                    </div>
                    <div class="col-md-4">
                        <p class="copyright">(C) 2015. All Rights Reserved. /www.synextech.info/Novex Science © 2015</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <p class="novex">
                             Novex Science <br>
                            <a href="https://www.youtube.com/channel/UCmjc-WGwUjjmRAhFXtth0IA" target="_blank"><i class="fa fa-youtube youtube"></i></a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>