<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('img/bg-image.png')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-heading">
                        <h1 class="tech-font">METABOLIC SCIENCE<sup>TM</sup></h1>
                        <span class="site-subheader">FOOD FOR MEDICAL PURPOSES</span> <br><br>
                        <span class="about-subheading">Metabolic Science is a research organization dedicated to the advancement of evidence-based medical nutrition.
                            Our researchers have studied the latest literature and have conducted extensive research to develop products that can
                            aid patients with specific medical conditions to manage their unique nutrient needs, as determined by healthcare
                            professionals.</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="about-products">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="tech-font">PRODUCTS</h1>
                    <p>
                        Metabolic Science products aim to elevate the medical nutrition field through precise formulations that
                        give patients their nutrient needs without aggravating their medical conditions. We study guidelines of
                        the world’s leading institutions such as the American Diabetes Association and the European Medicines
                        Agency to align with their recommendations. We also keep up to date with clinical studies in order to
                        properly and carefully formulate for specific patient needs. Our promise is to deliver safe and effective
                        medical nutrition products.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Content -->
    <div id="main" class="about-us">
        <!-- Footer -->
        <footer>
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->

                <div class="row">
                    <div class="col-md-4 img-footer">
                        <img src="img/footer-logo.png" alt="logo" height="125" style="padding: 25px">
                    </div>
                    <div class="col-md-4">
                        <p class="copyright">(C) 2016. All Rights Reserved. /www.metabolicscitech.info/Novex Science © 2016</p>
                    </div>
                    <div class="col-md-4 text-center">
                        <p class="novex">
                             Novex Science <br>
                            <a href="https://www.youtube.com/channel/UCmjc-WGwUjjmRAhFXtth0IA" target="_blank"><i class="fa fa-youtube youtube"></i></a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>