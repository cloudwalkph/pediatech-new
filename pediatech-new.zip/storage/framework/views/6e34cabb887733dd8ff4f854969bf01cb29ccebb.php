<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('img/banner.png')">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-heading">
                        <h1 class="tech-font">Metabolic Science<sup>TM</sup></h1>
                        <span class="subheading">Food for Medical Purposes</span> <br>
                        <span class="subheading">Metabolic Science is a research organization dedicated to the<br>
                            advancement of evidence-based medical nutrition.</span> <br>
                        <button class="btn btn-transparent">Learn More</button>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div id="main">
        <div class="separator-gradient"></div>
        <div class="container">
            <div class="col-lg-10 col-lg-offset-1 col-md-10 col-md-offset-1 carousel-text">
                <p>
                    <b>Metabolic Science</b> is a research organization dedicated to the advancement of evidence-based
                    medical nutrition.
                </p>
                <hr>
                <p>We deliver this promise by developing:</p>
            </div>

            <div class="col-md-12">
                <div class="wrap">
                    <div id="showcase" class="noselect">
                        <div class="card">
                            <img src="/img/carousel1.jpg" class="img-responsive">
                            <h4 class="tech-font">Nutrition as a Therapeutic Avenue</h4>
                            <p>
                                We cater to the needs of patients with unique nutrition requirements by developing products for their therapeutic use.
                            </p>
                        </div>
                        <div class="card">
                            <img src="/img/carousel2.jpg" class="img-responsive">
                            <h4 class="tech-font">Safe and Effective</h4>
                            <p>
                                We formulate without adding any ingredients that could be harmful for the patient or that could aggravate his condition.
                            </p>
                        </div>
                        <div class="card">
                            <img src="/img/carousel3.jpg" class="img-responsive">
                            <h4 class="tech-font">Precise Formulations</h4>
                            <p>
                                We formulate our products to address specific patient nutritional needs.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <!-- Footer -->
        <footer>
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->

                <div class="row">
                    <div class="col-md-4 img-footer">
                        <img src="img/footer-logo.png" alt="logo" height="125" style="padding: 25px;">
                    </div>
                    <div class="col-md-4">
                        <p class="copyright">(C) 2016. All Rights Reserved. /www.metabolicscitech.info/Novex Science © 2016 </p>
                    </div>
                    <div class="col-md-4 text-center">
                        <p class="novex">
                             Novex Science <br>
                            <a href="https://www.youtube.com/channel/UCmjc-WGwUjjmRAhFXtth0IA" target="_blank"><i class="fa fa-youtube youtube"></i></a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>